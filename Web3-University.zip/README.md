# Web3 University

This is a minimal prototype of Web3-Crypto University built for Telegram WebApp.
